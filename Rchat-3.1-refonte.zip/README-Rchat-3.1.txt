# Rchat 3.1 — refonte visuelle

## Fichiers
- index.html : accueil
- chat.html : chat
- defis.html : défis
- ia.html : assistant IA

Les quatre pages conservent leurs scripts et leurs connexions Supabase d'origine.
Le thème ajoute un fond photographique aléatoire parmi une sélection d'images Unsplash.
La même image reste sélectionnée pendant la navigation dans un même onglet (sessionStorage).
Une image de secours en dégradé est utilisée si le chargement échoue.

## Installation
Remplace les quatre fichiers HTML correspondants sur l'hébergement, en conservant les mêmes chemins.
Teste ensuite connexion, inscription, envoi de messages, défis, votes et accès Premium.

## Protection anti-robots : à activer côté hébergement
Le HTML ne peut pas assurer une protection complète. Pour une protection sérieuse du sous-domaine :
1. Place le sous-domaine derrière Cloudflare (DNS proxifié).
2. Active les protections DDoS et Bot Fight Mode disponibles sur le plan.
3. Ajoute des règles WAF adaptées aux routes sensibles et une limitation de débit sur les routes d'authentification.
4. Ajoute Cloudflare Turnstile aux formulaires d'inscription/connexion.
5. Vérifie obligatoirement le jeton Turnstile côté serveur avant l'action, via une Supabase Edge Function ou un backend. Ne place jamais le secret Turnstile dans le HTML.
6. Ajoute des limites de fréquence et des contrôles d'abus dans les Edge Functions (notamment IA et téléversements).
7. Vérifie les politiques RLS Supabase : le navigateur ne doit jamais pouvoir s'attribuer un rôle, un statut Premium ou des droits de modération.

Important : les protections Cloudflare et la vérification Turnstile nécessitent la configuration du domaine/DNS et du serveur. Elles ne sont pas activées automatiquement par le simple remplacement des fichiers HTML.
